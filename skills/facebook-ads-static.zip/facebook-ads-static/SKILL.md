---
name: facebook-ads-static
description: Writes, checks and tests Facebook and Instagram static ads from scratch, for first-time advertisers or teams wanting better results. Teaches how to write brilliant hooks and headlines (principles, 15 fill-in-the-blank formulas, a scoring checklist), then produces 20 ranked hooks, primary text, image text, headline field, CTA button, visual briefs and AI image prompts, carousels card by card, lead ad forms and follow-up emails. Runs a Meta policy check (personal attributes, before-and-after, fake scarcity), builds a one-variable-per-round Ads Manager test plan with budgets and kill and scale rules, and diagnoses results from metrics such as CPM, link CTR, CPC, hook rate, cost per result, ROAS and frequency. Use for write my Facebook ads, Meta ads, Instagram ads, ad copy, ad headlines, hooks, carousel ad, lead ads, ad test plan, why are my ads not working, or read my Ads Manager results. No brand kit or prior work needed.
---

# Facebook Ads: Static Ads and Test-and-Learn

This skill comes from Gareth Winter's Facebook Ads Live Build. It works on its own: you need no other skill, file or prior conversation.

**The idea.** Find the message that works on a single image first, because statics are cheap and fast to test. Spend money on video only once you know which angle wins.

## How to run this skill

1. **Get the minimum.** If the user hasn't given them, ask in one short message for: brand name, what they sell, who it's for, the price, and the goal (sales, leads, sign-ups). Also ask for any customer reviews or comments they can paste. Nothing else yet.
2. **Use what exists.** If the conversation contains a brand kit, insights, tone of voice rules or past ad results, read them and say what you're using. (If you've run facebook-ads-brand-kit or facebook-ads-insight, paste the output; both help, neither is required.)
3. **If there's no angle yet,** find one quickly: ask "What do customers say right before they buy, and what nearly stops them?" Write it as "I want ___, but ___, because ___. So our ad should ___." The "because" is the belief your ad will change.
4. **Ask what they need today** (hooks, a full feed ad, a carousel, a lead form, a test plan or results analysis) and go straight to that section. Default order for a new advertiser: sections 1 to 8.
5. Keep a running **BRAND KIT** document if useful (brand basics, tone, angles, winning ads), but never assume one exists. Use British spelling.

**Running example:** Fernhill, a houseplant subscription matched to your light and schedule, £18 a month, goal: subscriptions. (Illustration only.)

## 0. How Facebook decides who sees your ad (explain briefly, once)

On Facebook and Instagram today, **the creative is the targeting.** Meta's delivery system reads your ad (words, image, who engages) to work out who to show it to. So:

- Choose the campaign objective first: **Sales** if you sell online, **Leads** if you collect enquiries.
- Keep audiences broad (country, age range if relevant) and use Advantage+ placements unless you have a reason not to.
- Give each ad set several **genuinely different** ads: different angles, not different button colours.
- Install the Meta Pixel and the Conversions API before spending, or Meta can't learn who buys.
- Features, specs and policies change often. Tell the user to check Meta's current Business Help Centre and Advertising Standards before launch.

## 1. How to write a brilliant Facebook hook

The hook is the first thing people read: the line on the image, the first line of primary text, or both. On a phone in a fast-moving feed, it gets about a second. Its only job is to make the right person stop and read the next line.

### Principles

1. **Specific beats clever.** "Your plant died because of your window, not you" beats "Grow your green confidence." Specific details (numbers, places, objects, times) are believable and easy to picture.
2. **About the viewer, not the brand.** Lead with their problem, desire or situation. "We're passionate about plants" is about you. "That fern you killed wasn't your fault" is about them.
3. **One idea per ad.** If you need "and" to explain the hook, split it into two ads.
4. **Open a curiosity gap.** Give enough to intrigue, hold back the answer. "The one thing plant shops never ask you" makes people want the thing.
5. **Use stakes and tension words.** Words like *mistake, stop, never, finally, wasn't, actually, why* create tension. Use them honestly, never as bait the ad doesn't pay off.
6. **Numbers help.** "3 reasons" or "in 10 seconds" signal a quick, concrete payoff. Use real numbers only.
7. **Call out the audience by situation or interest, never by personal attribute.** "For anyone who's killed a 'low-maintenance' plant" calls out a situation. "Are you depressed?" asserts a personal attribute and breaks Meta policy (see section 2).
8. **Front-load the first 125 characters of primary text.** Facebook usually cuts primary text at roughly 125 characters with "See more". Everything that matters goes before that.
9. **Think thumb-stop and sound-off.** Most people scroll fast, many with sound off. The image and the words on it must work alone, in under a second, at phone size.
10. **Write for mobile.** Short words, short lines, no jargon. If you'd need to squint to read it on a phone, cut it.
11. **Sound like a person.** Read it aloud. If a friend wouldn't say it, rewrite it.

### Hook formulas (fill in the blanks)

| # | Formula | Template | Example |
|---|---|---|---|
| 1 | Situation callout | "For anyone who [situation]." | "For anyone who's killed a 'low-maintenance' plant." |
| 2 | It's not X, it's Y | "It's not [assumed cause]. It's [real cause]." | "It's not your green fingers. It's your window." |
| 3 | Contrarian | "Stop [common advice]. [Better way] instead." | "Stop watering on a schedule. Water by the soil." |
| 4 | Number list | "[Number] reasons [bad result] (and [twist])." | "3 reasons houseplants die (none of them are you)." |
| 5 | How to, without | "How to [outcome] without [pain]." | "How to keep plants alive without remembering to water." |
| 6 | The one mistake | "The one mistake that [bad result]." | "The one mistake that kills most houseplants." |
| 7 | Why question (about the situation) | "Why do [common thing] keep [bad result]?" | "Why do 'easy' plants keep dying?" |
| 8 | Insider secret | "What [insiders] don't tell you about [topic]." | "What garden centres don't tell you about light." |
| 9 | Us vs them | "[Old way] vs [new way]." | "Garden centre roulette vs a plant that fits your flat." |
| 10 | Objection killer | "[Objection]? [Answer]." | "North-facing flat? We've got plants for that." |
| 11 | Social proof (real numbers only) | "[Real number] people [did X]. Here's why." | "[Real number] flats matched. Here's what we learned." |
| 12 | Founder confession | "I [failure]. So I [built this]." | "I killed 11 plants. So I started matching them to windows." |
| 13 | Time to result | "[Outcome] in [real time]." | "Your plant, matched to your window, in 10 seconds." |
| 14 | Relatable moment | "That moment when [familiar situation]." | "That moment the 'unkillable' cactus goes soft." |
| 15 | Direct offer | "[Offer] for [situation]." | "Your first plant half price. Matched to your light." |

### Hook scoring checklist

Score each hook 1 point per yes. 8 or more: test it. 6 to 7: rewrite. Under 6: drop.

1. Is it about the viewer, not the brand?
2. Is it specific (a detail you can picture)?
3. Is there one idea only?
4. Does it create curiosity or tension?
5. Would the target customer recognise their own words or situation?
6. Is it readable on a phone in under 2 seconds (under 8 words for image text)?
7. Is it true, with every number and claim real?
8. Does the rest of the ad pay it off?
9. Does it avoid implying the viewer's personal attributes?
10. Could a competitor not run the exact same line?

### Common hook mistakes

- **Leading with the brand name or logo.** Nobody stops for a logo they don't know.
- **Clever wordplay that needs a second read.** People won't give it one.
- **Vague benefit words:** "amazing", "game-changing", "transform your life".
- **Two ideas at once.** "Healthier plants and a greener planet" says nothing strongly.
- **Clickbait the ad doesn't pay off.** It wins clicks and loses sales, and Meta may penalise low-quality engagement.
- **Questions that assert personal attributes:** "Struggling with anxiety?" Rejected by Meta and off-putting.
- **Burying the hook** after a greeting or context line in primary text.

### Write 20 before judging one

The first hooks you write are usually the obvious ones. Write volume first, judge later (some call this "running the tap": let the water run until it runs clear). From the strongest angle, write **20 hooks** across these types: pain, dream outcome, social proof, contrarian, humour, us vs them, founder, objection killer, the offer. Don't filter while writing. Then score all 20 on the checklist and rank the top five, with one sentence each on why.

## 2. Meta policy check (run on every piece of copy before handing over)

### Personal attributes

Meta rejects ads that assert or imply a person's personal attributes. These include: health (physical or mental), medical conditions, financial status, age, appearance and body, race or ethnicity, religion or beliefs, sexual orientation, gender identity, disability, criminal record, membership of a trade union, voting or political affiliation. The trigger is usually "you" plus an attribute.

**Agitate the situation, not the person.**

| Fails | Passes |
|---|---|
| "Are you struggling with debt?" | "Debt doesn't have to be the plan." |
| "Tired of being overweight?" | "A simpler way to plan balanced meals." |
| "Over 50? You need this." | "Retirement planning, made simple." |
| "Feeling anxious every night?" | "Tools for calmer evenings." |
| "Your skin looks dull." | "Skincare for a brighter-looking routine." |
| "Meet other gay singles near you." | "A dating app for the LGBTQ+ community." |

### Other rules to check

- **Before-and-after images:** for weight loss, cosmetic procedures and many health products, Meta restricts or rejects before-and-after imagery and images that focus on body parts or imply a negative self-image. Use the product, the process or the lifestyle instead. Weight-loss ads must be targeted to adults (18+).
- **No fake scarcity:** no fake countdowns, invented "only 3 left" or deadlines that reset. Use real deadlines, real stock levels or real seasonal moments only.
- **Never invent reviews, testimonials, statistics or results.** If a claim needs proof, use the user's real proof or remove it.
- **Special Ad Categories:** ads about credit, employment, housing, social issues, elections or politics must be declared, and targeting is restricted.
- **Misleading claims:** no exaggerated health claims, guaranteed income promises or fake features (play buttons on static images, fake notification badges).

Flag every risky line, explain why, give a compliant rewrite, and tell the user to check Meta's current Advertising Standards because they change.

## 3. Narratives: three ways to tell the same angle

For the chosen angle, write the ad in three narrative structures so the user can test structure later.

- **PAS (Problem, Agitate, Solve)**, a classic direct-response formula. Name the problem, make it felt (situation, not personal attribute), present the solution. Example: "Bought another 'easy' plant? Watched it brown in a month? Most plants die from the wrong window, not the wrong owner. Fernhill matches each plant to your light."
- **BAB (Before, After, Bridge).** Show the current state, the desired state, then the product as the bridge. Example: "Before: a windowsill graveyard. After: a flat that feels alive. The bridge: plants matched to your light, delivered monthly."
- **Pope in the Pool** (Blake Snyder, *Save the Cat*). Snyder's screenwriting trick: deliver dull but necessary information inside something entertaining, as in a film where exposition happens while the Pope swims laps. In an ad: wrap the boring part (how it works, the price) in something fun to watch or read. Example: a deadpan "plant obituary" image that explains in its small print why the plant died and how matching would have saved it.

Other structures on request:
- **Hook, Story, Offer** (Russell Brunson, *DotCom Secrets*): a hook to stop the scroll, a short story that builds belief, then the offer.
- **HSTSS: Hook, Stakes, Turn, Scene, Shatter** (Vishen Lakhiani, Mindvalley; the initials also stand for "Holy shit, that's so smart", the reaction it aims for). See section 5 for the steps and an example.
- Customer as hero, myth-busting, listicle, demo, social proof, founder story, controversy (attack a belief or a habit, never a person).

## 4. The Facebook feed ad, field by field

### Primary text (above the image)

Structure for cold audiences:
1. **Line 1, the hook** (within the first 125 characters).
2. **Line 2 to 3, the tension:** the situation, in the customer's words.
3. **Line 4 to 5, the turn:** the insight or mechanism. Why this is different.
4. **Proof:** one real piece (review line, number, guarantee).
5. **Offer and call to action:** what to do and why now (honest reason only).

Short lines, white space between them, one or two emojis at most if the brand tone allows. Write a short version (under 125 characters, the hook alone does the job) and a long version (80 to 150 words). Long often works for higher-priced or less familiar products; test both.

### Image text (words on the image)

- Under 8 words. Ideally the hook or a sharper cut of it.
- Large enough to read at thumbnail size: check on a phone.
- Strong contrast with the background.
- Don't repeat the primary text word for word; complement it.
- Meta no longer rejects images for text quantity, but less text usually performs better.

### Headline field (below the image)

- Under 40 characters, as it may truncate on mobile.
- Usually the benefit or the offer, since the hook is above. Example: "Plants matched to your light."

### Description (optional)

Under 30 characters. Often hidden on mobile. Use for a supporting detail: "Free delivery. Cancel anytime."

### CTA button

Choose from Meta's list based on intent:

| Button | Use when |
|---|---|
| Shop now | Selling products directly online. |
| Learn more | Higher-priced or unfamiliar products, cold audiences needing more information. |
| Sign up | Subscriptions, newsletters, free trials, accounts. |
| Get offer | A genuine discount or promotion is the main message. |
| Book now | Appointments, classes, events, travel. |
| Subscribe | Recurring products or content. |
| Get quote / Apply now | Services and lead generation. |
| Send message | You want a conversation in Messenger or WhatsApp. |
| Download | Apps, guides, lead magnets. |

Test "Learn more" against the direct action button if unsure; softer buttons often get more clicks, direct ones often better-qualified clicks.

### Visual brief and AI image prompt

**Thumb-stop principles:**
- **Faces stop the scroll,** especially looking at the camera or showing a clear emotion.
- **High contrast** between subject and background, and between text and background.
- **One focal point.** If the eye doesn't know where to land, it moves on.
- **Native look vs polished:** phone-shot, real-looking images often beat studio-perfect ones because they look like a friend's post. Polished can work for premium brands. Test both.
- **Show the outcome or the problem,** not the logo.
- **Pattern interrupt:** something slightly unexpected (an odd angle, a surprising object, a bold colour block).
- **Check it at thumbnail size** and in greyscale: if it still reads, it works.

**Sizes:** feed images 4:5 (1080 x 1350 px) take up the most space on mobile. Stories and Reels are 9:16 (1080 x 1920 px): keep text and key elements away from roughly the top 15% and bottom 30 to 35%, where buttons and captions sit. Carousels are 1:1 (1080 x 1080 px) by default. Check Meta's current specs.

**Visual brief template:** subject, setting, composition, focal point, emotion, colours (brand hex codes), text placement, style (native or polished), must avoid.

**AI image prompt template:** "[Subject] [doing action] in [setting], [composition and camera angle], [lighting], [style: e.g. candid phone photo / editorial], colour palette [hex codes], space for text at [top/bottom], 4:5 vertical, no text, no logos." Add text afterwards in a design tool, as AI image tools often misspell words.

## 5. Carousel, card by card

A carousel shows 2 to 10 swipeable cards. Each card has its own image, headline and link. Six cards is a strong default.

**HSTSS shape** (Vishen Lakhiani). The five steps:
1. **Hook:** a line that stops the scroll.
2. **Stakes:** why it matters, what it costs to ignore.
3. **Turn:** the surprising reframe or insight.
4. **Scene:** a concrete, visual moment that makes it real.
5. **Shatter:** the line that breaks the old belief and lands the "that's so smart" moment, followed by the action.

**Card plan:**

| Card | Job | Fernhill example |
|---|---|---|
| 1 | Hook. Must work alone (many people never swipe). | "It wasn't you. It was the plant." |
| 2 | Stakes: the problem. | "Most 'easy' plants die in the wrong window." |
| 3 | Turn: the insight. | "Light matters more than skill." |
| 4 | Scene / proof: show it. | Photo of a thriving plant on a real north-facing sill, plus a real review line. |
| 5 | Shatter + offer. | "Matched to your window. £18 a month." |
| 6 | Repeat the hook with the CTA. | "Plant person after all? Start here." |

Rules: under 15 words per card, a headline per card (under 40 characters), a visual note per card, consistent design so it reads as one story, primary text above that works alone. When testing a story order, switch off Facebook's option to automatically show the best-performing cards first. Product carousels (one product per card) are a different format: use them for catalogues.

## 6. Lead ad form and follow-up email

### Lead ad form

- **Form type:** "More volume" for cheap leads, "Higher intent" (adds a review screen) for better-qualified leads.
- **Intro:** a headline repeating the ad's promise exactly, plus one or two lines on what they get.
- **Questions:** 2 to 4 maximum. Use pre-filled name and email where possible. Add one qualifying question if lead quality matters ("What's your budget?" or "When are you looking to start?"). Every extra question lowers volume.
- **Privacy policy link** (required) and a short line on how you'll use their details.
- **Thank-you screen:** one next step (visit the site, book a call, check your inbox).
- Connect the form to your email or CRM tool so follow-up happens automatically.

### Follow-up email (send within minutes; interest fades fast)

**Subject lines:** write five, under 45 characters, one of each type:

| Type | Template | Example |
|---|---|---|
| Curiosity | "The [thing] nobody tells you" | "The window test nobody tells you" |
| Benefit | "[Outcome], [timeframe]" | "Your matched plant, in 3 days" |
| Question | "[Relevant question]?" | "Which way does your window face?" |
| Number | "[Number] [things]" | "3 plants that love dark flats" |
| Personal | "[Name], [direct line]" | "Sam, your plant guide is here" |

Add **preview text** (35 to 90 characters) that continues the subject line rather than repeating it.

**Body:** a banner headline matching the ad, one idea, short paragraphs, one button, and a P.S. that restates the offer (many people read the P.S. first). Deliver whatever the form promised in the first email.

## 7. Test plan: one variable per round

**Rule:** change one thing per round and lock everything else, or you won't know what caused the result.

| Round | Variable | Set-up |
|---|---|---|
| 1 | Angle | 3 different hooks/angles, same image style, same audience, same budget. |
| 2 | Visual | Winning hook on 3 different visuals. |
| 3 | Format | Winning pair as feed image, carousel and 9:16 Stories/Reels. |
| 4 | Video | Only now make video from the winner. |

**Learning phase.** Meta's delivery needs roughly 50 optimisation events (results) per ad set within 7 days to leave the learning phase. Significant edits (creative, budget jumps, targeting) reset it, so don't edit during a test.

**Budget.** Rough guide: daily budget = (50 x target cost per result) / 7. At a £20 target cost per acquisition, that's about £143 a day. If that's out of reach, either optimise for an earlier event (add to cart, landing-page view, lead) or judge the test on an earlier metric (link CTR, cost per landing-page view) and say so.

**Even splits.** Meta's built-in A/B test (Experiments) splits budget evenly, which gives the cleanest read. Putting three ads in one ad set is cheaper but Meta will favour one early.

**Duration.** At least 3 to 7 days, covering weekdays and a weekend.

**Kill and scale rules (adapt to the account):**
- **Kill** an ad that spends 2 to 3 times the target cost per result with no results, or has a link CTR well below the others after a fair spend.
- **Keep watching** ads within about 20% of target.
- **Scale** a winner by raising budget about 20% every few days, or duplicate it into a new ad set with a larger budget. Large jumps can reset learning.
- While testing, switch off Advantage+ creative enhancements so Meta doesn't alter the variable you're testing.

For each round, write: hypothesis, variable, what's locked, audience, budget and split, duration, deciding metric, kill rule, scale rule.

## 8. Reading Ads Manager results

Ask the user to export or paste, per ad: ad name, spend, impressions, reach, frequency, CPM, link clicks, link CTR, CPC (link), 3-second video plays and ThruPlays (for video), landing-page views, results, cost per result, purchase value, ROAS.

**What each metric means:**
- **CPM:** cost per 1,000 impressions. How expensive it is to reach people. Rising CPM can mean competition or a weak ad Meta is reluctant to show.
- **Link CTR:** link clicks / impressions. Does the ad make people want more?
- **CPC (link):** cost per link click.
- **Hook rate (video):** 3-second plays / impressions. Did the opening stop the scroll?
- **Hold rate (video):** ThruPlays / 3-second plays (definitions vary; state which you use). Did the story keep them?
- **Landing-page view rate:** landing-page views / link clicks. Low means a slow page or accidental clicks.
- **Cost per result:** spend / results. Usually the deciding metric.
- **ROAS:** purchase value / spend. Revenue per pound spent.
- **Frequency:** average times each person saw the ad. Above roughly 3 with falling results usually means fatigue.

Benchmarks vary hugely by industry and country. Compare ads against each other and against the account's own history more than against published averages.

**Diagnostic table:**

| Symptom | Likely problem | Fix |
|---|---|---|
| Low hook rate or low link CTR, normal CPM | The hook or image isn't stopping the scroll. | New hooks, stronger focal point, face, contrast. |
| High CPM, low engagement | Ad seen as low relevance, or audience too narrow. | New creative, broader audience. |
| Good CTR, low landing-page view rate | Slow page or misleading ad. | Speed up the page, match the ad's promise. |
| Good CTR, poor cost per result | Page or offer doesn't keep the ad's promise. | Match headline and image on the page, strengthen offer, reduce form fields. |
| Good hook rate, low hold rate (video) | Strong opening, weak middle. | Tighter script, show payoff sooner. |
| Results falling, frequency above 3 | Creative fatigue. | Refresh creative (new angle or visual), not targeting. |
| Good results, high ROAS, low spend | A winner held back. | Scale gradually. |

**Then:**
1. Sort ads into gold (best third), silver and bronze by cost per result. (Adapted from Brendan Kane's research method in *Hook Point*.)
2. Write the finding: "Gold does [tactic], which makes the viewer feel [effect]. Bronze does [tactic], so they feel [effect]."
3. Recommend the next round: what to keep, what to kill, what to test next.

Never invent results. If data is thin (few results), say the read is directional, not conclusive.

## Deliverable

```
STATIC AD PACK: [Brand] | Angle: [angle]

TOP 5 HOOKS (score /10, why)
1. ...

FEED AD
Primary text (short): ...
Primary text (long): ...
Image text: ...
Headline: ...
Description: ...
CTA button: ... (why)
Visual brief: ...
AI image prompt: ...
Sizes: 4:5 feed, 9:16 Stories/Reels

NARRATIVE VARIANTS: PAS / BAB / Pope in the Pool

CAROUSEL (6 cards): card | text | headline | visual

LEAD FORM (if leads): type | intro | questions | thank-you screen
FOLLOW-UP EMAIL: 5 subject lines + preview text | body | P.S.

POLICY CHECK: flagged lines | why | compliant rewrite
Check Meta's current Advertising Standards and specs before launch.

TEST PLAN: round | hypothesis | variable | locked | budget | duration | deciding metric | kill | scale

RESULTS (if supplied): gold/silver/bronze | finding | diagnosis | next round
```

Close by saying: "When you have a tested winner, it's ready to become a video. The optional companion skill facebook-ads-video does that."
