---
name: facebook-ads-static
description: Writes and tests Facebook and Instagram static ads: 20 ranked hooks, narratives, feed ads in Facebook's real fields, carousels, lead ad forms, follow-up emails, a one-variable-per-round Ads Manager test plan, and results analysis. Includes Meta policy checks. Use for "write my Facebook ads", "carousel", "test plan", "read my Ads Manager results".
---

# Facebook Ads: Static Ads and Test-and-Learn

Part 3 of 4 in Gareth Winter's Facebook Ads Live Build. Find the angle that works on a single frame first, then spend money making it move. Read MY BRAND KIT (voice, visual identity, insights) before writing anything.

## How Facebook finds people (explain once, briefly)

On Facebook, the creative is the targeting. The delivery system reads your ad to decide who sees it, so: pick the campaign objective first (Sales or Leads), keep audiences broad, use Advantage+ placements, and give each ad set several genuinely different ads (different angles, not different button colours). Install the Meta Pixel and Conversions API before spending. Specs and features change: tell the user to check Meta's current help pages.

## 1. Twenty hooks before judging one (after Hook Point's "Run the Tap")

From the top insight, write 20 Facebook ad headlines under 8 words across: pain, dream outcome, social proof, contrarian, humour, us vs them, founder, objection killer, the offer. Don't filter while writing. Then rank the top 5 with reasons, on evidence not taste.

## 2. Narratives

Show one angle in three narratives: Problem-Agitate-Solve, Before-After-Bridge, Pope in the Pool (deliver dull information inside something entertaining; Blake Snyder, Save the Cat). Others on request: Hook-Story-Offer, customer as hero, controversy (attack a belief, never a person), listicle, myth-busting, us vs them, demo, social proof, founder story.

## 3. Facebook feed ad (real fields)

- Primary text: the hook in the first ~125 characters, before "See more".
- Text on the image: under 8 words, readable on a phone.
- Visual brief for a 4:5 image (1080×1350), plus an AI image prompt in the brand's visual identity.
- Headline under the image: under 40 characters.
- Description: optional, under 30 characters.
- CTA button from Facebook's list (Shop now, Learn more, Sign up, Get offer).
Placements: feed 4:5, Stories and Reels 9:16 (keep top and bottom clear), carousel up to 10 cards.

## 4. Carousel

Six cards: 1 hook (works alone), 2 problem, 3 turn, 4 proof, 5 CTA and offer, 6 repeat the hook. Shape it with HSTSS (Hook, Stakes, Turn, Scene, Shatter; Vishen Lakhiani's "Holy shit, that's so smart"). Max 15 words per card, a headline per card (under 40 characters), primary text above, a visual note per card. When testing story order, switch off Facebook's automatic card reordering.

## 5. Lead ad form and follow-up email

Lead form: intro headline repeating the ad's promise, 2 to 4 questions maximum (prefer pre-filled name and email), a privacy line, a thank-you screen with one next step. Follow-up email, sent within minutes: 5 subject lines (curiosity, benefit, question, number, personal; under 45 characters) with preview text, a banner headline, one idea, one button, a P.S. restating the offer.

## 6. Meta policy check (always run before handing over copy)

Facebook rejects ads that say or imply the viewer's personal attributes: health (physical or mental), finances, age, appearance, race, religion, sexual orientation, criminal record and similar. "Are you struggling with debt?" fails; "Debt doesn't have to be the plan" passes. Agitate the situation, not the person. Weight-loss and health ads face limits on before-and-after images. Flag risky lines and rewrite them; tell the user to check Meta's Advertising Standards.

## 7. Test plan: back the winning horse

One variable per round, everything else locked:
- Round 1 angle: 3 headlines, same visual, same broad audience, same budget.
- Round 2 visual: the winning headline on 3 visuals.
- Round 3 format: the winning pair as feed, carousel and Stories/Reels.
- Round 4: only now, make the video (facebook-ads-video skill).
For each round give audience, budget split, duration, the deciding metric (usually cost per result) and the kill rule. An ad set needs roughly 50 results a week to leave the learning phase; if the budget can't reach that, judge on an earlier metric (cost per landing-page view or link CTR). Don't edit mid-test. Switch off Advantage+ creative enhancements while testing.

## 8. Reading Ads Manager results

Ask for: ad name, spend, impressions, CPM, 3-second plays, link CTR, cost per link click, results, cost per result, ROAS, frequency. Then:
- Sort into gold, silver and bronze by cost per result (adapted from Hook Point's research method).
- Write the finding: "Gold does [tactic], which makes the viewer feel [effect]. Bronze does [tactic], so they feel [effect]."
- Diagnose each loser: stop (hook rate = 3-second plays ÷ impressions, or link CTR for statics; rising CPM), click (link CTR), convert (cost per result: the page or offer isn't keeping the ad's promise).
- Frequency above roughly 3 with falling results means fatigue: refresh creative, not targeting.
Save the winner in MY BRAND KIT. Then say: "Next: the facebook-ads-video skill."

Never invent results, reviews or numbers.
