---
name: facebook-ads-video
description: Turns a winning Facebook static ad into Reels, Stories and feed video ads: 15-second scripts, funny versions, AI video shot prompts, hook variants to test hook rate, and an AI workflow plan. Use when someone has a tested winning static, or asks for a Facebook video ad, Reels ad script or AI video prompts.
---

# Facebook Ads: Video and AI Workflow

Part 4 of 4 in Gareth Winter's Facebook Ads Live Build. Back the winning horse: the static that won the test becomes the brief. No new ideas; we scale what's proven. Read MY BRAND KIT and the winning ad first. If there is no tested winner, say so and offer to use the strongest untested angle, labelled as unproven.

## 1. The static is the storyboard

Map each part of the winning static: headline → the first 3 seconds, said out loud and on screen; visual → the opening frame; proof line → the middle, shown not said; primary text → the post copy; CTA → the end card.

## 2. Script: 15-second Facebook Reels ad (9:16)

0–3s hook using the exact winning headline (Facebook measures this as hook rate: 3-second plays ÷ impressions); 3–6s problem; 6–11s turn or demo; 11–13s proof; 13–15s CTA. Include on-screen captions (most people watch with the sound off), a shot list, a 4:5 crop note for the feed, the primary text, and a 30-second version for retargeting people who already know the brand. Open on a human face or the payoff, never a logo or slow intro. Shape it with HSTSS (Hook, Stakes, Turn, Scene, Shatter).

## 3. Make it funny (optional)

Rewrite in one or two comedy formats: exaggeration, deadpan, fake infomercial, POV, the twist, the enemy. The joke must carry the reason to buy: remove the joke and the reason should go with it. Stay within the brand's tone dials.

## 4. AI video shot prompts

For each shot: subject, action, camera move, lighting, style, about 5 seconds, 9:16. Keep characters, setting and colours consistent across shots and matched to the visual identity. Note where real footage (a real customer, a real product demo) would beat AI.

## 5. Hook variants

Write 5 new opening hooks for the same video (question, bold claim, visual surprise, problem, curiosity gap) and keep the rest identical, so the hook is the only variable in the next Ads Manager test.

## 6. Policy check

Run the same Meta personal attributes check as for statics: no copy or voiceover that says or implies the viewer's health, finances, age or appearance; care with before-and-after visuals.

## 7. What to hand to AI (skill × enjoyment)

List the workflow (brief, insights, angles, copy, visuals, video, captions, launching in Ads Manager, reporting). Ask the user, for each, whether they're good at it and enjoy it, then sort into: do it myself; learn it with AI; collaborate with AI; automate it. Name the first thing to automate this week. The human keeps purpose and taste.

## 8. Save the brand kit

Finally, turn MY BRAND KIT into one document under 400 words (sections, voice rules, three insights, winning ad) that the user can paste at the top of any future AI chat to get on-brand Facebook ads.
