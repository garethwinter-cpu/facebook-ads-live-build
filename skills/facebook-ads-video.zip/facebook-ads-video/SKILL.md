---
name: facebook-ads-video
description: Writes Facebook and Instagram video ads for Reels, Stories and feed, for anyone starting cold or turning a winning static ad into video. Teaches how to hook viewers in the first 3 seconds, structures 15-second and 30-second scripts with HSTSS (Hook, Stakes, Turn, Scene, Shatter), writes sound-off captions and shot lists for 9:16 and 4:5, covers pacing, gives comedy formats with how-to steps, AI video shot prompts with a reusable template, and hook variants to test hook rate and hold rate in Ads Manager. Includes a Meta policy check and a plan for which parts of the ad workflow to hand to AI. Use for Facebook video ad, Reels ad script, Instagram Reels ad, Stories ad, UGC script, funny ad, AI video prompts, turn my static ad into a video, or improve my hook rate. No brand kit or prior work needed.
---

# Facebook Ads: Video and AI Workflow

This skill comes from Gareth Winter's Facebook Ads Live Build. It works on its own: you need no other skill, file or prior conversation.

**The idea.** Video costs more to make than a static image, so scale what's already proven. If a static ad has won a test, it becomes the brief: same angle, same hook, now moving. If nothing has been tested yet, you can still write video, but label it unproven and plan to test hooks.

## How to run this skill

1. **Get the minimum.** If the user hasn't given them, ask in one short message for: brand name, what they sell, who it's for, the price, the goal, and whether they have a winning ad (paste it, with its results if possible).
2. **Use what exists.** If the conversation contains a brand kit, insights, tone of voice rules or a winning static, read them and say what you're using. (If you've run facebook-ads-brand-kit, facebook-ads-insight or facebook-ads-static, paste the output; they help, none is required.)
3. **If there's no winner and no angle,** find one quickly: ask "What do customers say right before they buy, and what nearly stops them?" Write it as "I want ___, but ___, because ___. So our ad should ___." Use the strongest hook you can write from it and label the video "unproven: test hooks first".
4. Ask what they can film: a phone and a person, product only, existing footage, or AI-generated video. Shape the scripts to that.
5. Keep a running **BRAND KIT** document if useful, but never assume one exists. Use British spelling.

**Running example:** Fernhill, a houseplant subscription matched to your light and schedule, £18 a month. Winning static hook: "It wasn't you. It was the plant." (Illustration only.)

## 1. The static is the storyboard

If there's a winning static, map it directly:

| Static element | Becomes in video |
|---|---|
| Headline / image text | The first 3 seconds: said out loud and shown as on-screen text |
| Image | The opening frame |
| Proof line | The middle: shown, not just said |
| Primary text | The post copy above the video (keep it) |
| CTA button and offer | The end card |

Don't change the angle. The point is to learn whether motion improves a message you already know works.

## 2. How to hook in the first 3 seconds

Meta reports **hook rate** indirectly: 3-second video plays divided by impressions. It tells you what share of people stopped. A weak opening wastes the rest of the ad.

### Principles

- **Start on the most interesting frame.** A face mid-sentence, the payoff, the problem in action. Never a logo, a slow fade-in or "Hi, I'm...".
- **Hook in three layers at once:** what they **see** (visual), what they **read** (on-screen text) and what they **hear** (voice). Many people have sound off, so the visual and text must work without audio.
- **Movement or change in the first second:** something enters, falls, flips, is revealed.
- **Faces and eye contact** stop the scroll. So do hands doing something.
- **Say the hook within 1 to 2 seconds.** No warm-up.
- **One idea.** Same rule as statics.
- **Native feel.** On Reels, ads that look like normal Reels (phone-shot, a person talking, trending pacing) often beat polished commercials. Test both.
- **Call out the situation, not the person** (see section 7).

### Opening formulas

| Type | What happens on screen | Fernhill example |
|---|---|---|
| Spoken hook to camera | Person says the winning line straight away | "It wasn't you. It was the plant." |
| Visual surprise | Something unexpected in frame 1 | A dead plant in a tiny coffin, deadpan |
| Problem in action | The pain, shown | Leaves dropping in slow motion onto a windowsill |
| Payoff first | Show the result, then rewind | A lush windowsill, text: "6 months ago this was a graveyard" (only if true) |
| Bold claim on text | Large on-screen text over simple footage | "Your window decides if your plant lives." |
| Question about the situation | Text or voice | "Why do 'easy' plants keep dying?" |
| Curiosity gap | Hold back the answer | "Plant shops never ask you this one question." |

## 3. Script: the 15-second Reels ad (9:16)

### Structure using HSTSS

**HSTSS: Hook, Stakes, Turn, Scene, Shatter** is a storytelling structure from Vishen Lakhiani, founder of Mindvalley. The initials also stand for the reaction it aims for: "Holy shit, that's so smart." The steps:

1. **Hook:** stop the scroll with a line or image.
2. **Stakes:** why it matters, what it costs to ignore.
3. **Turn:** the surprising reframe, the insight the viewer didn't expect.
4. **Scene:** a concrete moment that makes it real (show, don't tell).
5. **Shatter:** the line that breaks the old belief, followed by the call to action.

### Timing for 15 seconds

| Time | Beat | Job |
|---|---|---|
| 0 to 3s | Hook | The winning headline, said and shown |
| 3 to 6s | Stakes / problem | The situation, in the customer's words |
| 6 to 11s | Turn and scene | The insight, shown with a demo or moment |
| 11 to 13s | Proof | One real proof point, on screen |
| 13 to 15s | Shatter and CTA | The new belief, the offer, what to tap |

### Worked example (Fernhill, 15s)

| Time | Visual | On-screen text | Voice |
|---|---|---|---|
| 0 to 3s | Close-up: woman holding a dead fern, looks at camera | "It wasn't you." | "It wasn't you. It was the plant." |
| 3 to 6s | Quick cuts: three dead plants on a dark windowsill | "Wrong plant. Wrong window." | "Most plants die in the wrong light." |
| 6 to 11s | Phone photographs window; app shows a matched plant | "Snap your window. Get a match." | "We match every plant to your actual light." |
| 11 to 13s | Same windowsill, thriving plant | [Real review line] | (music only) |
| 13 to 15s | End card, brand colours | "Plant person after all? £18/month" | "Plant person after all. Tap to get yours." |

### Also write

- **A 30-second version** for retargeting people who already know the brand: more proof, objection handling, the offer explained.
- **Primary text** above the video (hook in the first 125 characters).
- **A shot list:** every shot, framing, action, duration.

### Captions and sound-off

- Burn in captions (on-screen text) for all speech. Don't rely on auto-captions.
- Large, high-contrast text, two to six words per line, one line at a time where possible.
- Place text inside the safe zone: for 9:16, keep text and key action away from roughly the top 15% and bottom 30 to 35% of the frame, where Reels buttons and captions sit. Check Meta's current safe-zone guidance.
- Use music or sound design that suits the brand tone, but the story must still work muted.

### Formats

- **9:16 (1080 x 1920):** Reels and Stories. Primary format.
- **4:5 (1080 x 1350):** feed. Note how each shot crops from 9:16 to 4:5 so nothing important is lost.
- Most placements accept both; supply both rather than letting Meta crop. Check current specs.

### Pacing

- A new shot or visual change roughly every 1 to 2 seconds in a 15-second ad.
- Cut out breaths, pauses and "um"s. Jump cuts are normal on Reels.
- Show the product in use within the first half.
- Repeat the key line twice: once early, once at the end.
- Keep the end card short (1 to 2 seconds); many viewers drop before it, so the offer should also appear earlier.

## 4. Make it funny (optional)

Comedy can lift attention, but **the joke must carry the reason to buy**: if you remove the joke and the reason to buy disappears with it, the joke is doing its job. If the joke could sell any product, rewrite it. Stay within the brand's tone of voice.

| Format | How to write it | Fernhill example |
|---|---|---|
| **Exaggeration** | Take the real problem and push it to absurd extremes. | A plant "funeral" with mourners, eulogy for "Fern number 7". |
| **Deadpan** | Say something ridiculous with a completely straight face, no music, no wink. | Person to camera, flat voice: "I have killed 11 plants. I've named them all." |
| **Fake infomercial** | Parody an old TV advert: "Tired of THIS?" black-and-white struggle, then colour solution. | Black-and-white flailing with a watering can, cut to colour and a thriving plant. |
| **POV** | On-screen text "POV: [relatable situation]", filmed from the viewer's view. | "POV: you bought the 'unkillable' plant." Camera pans to a brown cactus. |
| **The twist** | Set up one expectation, reveal another. | Looks like a breakup video ("It's not you, it's me"), revealed as a person talking to a plant. |
| **The enemy** | Personify the problem as a character. | "The Dark Corner" as a villain who has claimed every plant. |

Steps: pick one format, write the setup in one line, write the payoff in one line, check the payoff lands the product's reason to buy, then cut everything else.

## 5. AI video shot prompts

Use AI video where filming is impractical. Keep each shot short (about 5 seconds) and 9:16.

**Template (one per shot):**

"[Subject, with consistent description] [specific action] in [setting]. Camera: [shot size and movement, e.g. close-up, slow push in]. Lighting: [e.g. soft morning daylight from a window]. Style: [e.g. candid handheld phone footage / clean editorial]. Colour palette: [brand hex codes or colour words]. Mood: [one word]. Duration about 5 seconds, vertical 9:16. No text, no logos."

**Consistency rules:**
- Describe the character identically in every prompt (age range, hair, clothing, setting) or use the tool's character reference feature.
- Keep setting, lighting and colours identical across shots.
- Add text, captions and logos afterwards in an editor; AI tools often misspell text.

**Where real footage wins:** real customers, real product demonstrations, real results, and anything used as proof. Never use AI to fake testimonials, results or people presented as real customers.

## 6. Hook variants: make the hook the only variable

Write **five new openings** for the same video (the first 3 seconds only) and keep everything after second 3 identical:

1. Question about the situation
2. Bold claim
3. Visual surprise
4. Problem in action
5. Curiosity gap

**Testing:**
- Run them as separate ads in the same ad set or a Meta A/B test, same budget and audience.
- Judge the hook on **hook rate** (3-second plays / impressions).
- Judge the body on **hold rate** (ThruPlays / 3-second plays; definitions vary, so state yours).
- The final judge is still **cost per result**: a hook that stops people but attracts the wrong ones isn't a winner.
- Diagnose: high hook rate, low hold rate means the middle is weak; low hook rate means the opening is weak; good both with poor cost per result means the page or offer isn't keeping the promise.

## 7. Meta policy check (run on every script)

Check the voiceover, on-screen text and visuals:

- **Personal attributes:** never assert or imply the viewer's health (physical or mental), finances, age, appearance or body, race or ethnicity, religion, sexual orientation, gender identity, disability, criminal record and similar. "You" plus an attribute is the usual trigger.

| Fails | Passes |
|---|---|
| "Are you overweight?" | "Meal planning that fits a busy week." |
| "Drowning in debt?" | "A clearer way to plan your money." |
| "Hate how you look in photos?" | "Skincare for a simpler morning routine." |

- **Before-and-after:** for weight loss, cosmetic and many health products, Meta restricts or rejects before-and-after visuals and footage focusing on body parts or implying negative self-image. Show the product, process or lifestyle instead.
- **No fake scarcity:** no fake countdowns or invented "last chance" claims.
- **Never invent reviews, results or statistics,** and never present actors or AI people as real customers.
- **No fake interface elements** such as fake notifications or buttons.

Flag risky lines, give compliant rewrites, and tell the user to check Meta's current Advertising Standards because they change.

## 8. What to hand to AI (skill x enjoyment)

List the ad workflow: brief, research and insights, angles, copy, visuals, video, captions, launching in Ads Manager, reporting. For each, ask the user two questions: am I good at it? Do I enjoy it? Then sort:

| | Enjoy | Don't enjoy |
|---|---|---|
| **Good at it** | Do it myself | Collaborate with AI |
| **Not good at it** | Learn it with AI | Automate it |

Name the first task to automate this week. The human keeps purpose and taste: deciding what's true, what's on brand and what's good.

## Deliverable

```
VIDEO AD PACK: [Brand] | Angle: [angle] | Status: [Proven winner / Unproven]

STATIC TO STORYBOARD MAP (if winner supplied)

15-SECOND REELS SCRIPT (9:16)
Time | Visual | On-screen text | Voice

30-SECOND RETARGETING SCRIPT

SHOT LIST: shot | framing | action | duration | 4:5 crop note

PRIMARY TEXT

FUNNY VERSION (optional): format | setup | payoff | script

AI SHOT PROMPTS: one per shot, using the template

5 HOOK VARIANTS (first 3 seconds only)

TEST PLAN: variants | budget | deciding metrics (hook rate, hold rate, cost per result)

POLICY CHECK: flagged lines | why | compliant rewrite
Check Meta's current Advertising Standards and specs before launch.

AI WORKFLOW: do / learn with AI / collaborate / automate. First to automate: ...
```

Finally, offer to compress everything learned (brand, voice, insights, winning ads) into one document under 400 words that the user can paste at the top of any future AI chat to get on-brand Facebook ads.
