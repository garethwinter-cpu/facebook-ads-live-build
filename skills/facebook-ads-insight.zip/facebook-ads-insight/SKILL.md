---
name: facebook-ads-insight
description: Finds the human insights behind why people buy, so Facebook and Instagram ads say something true and surprising instead of listing features. Shows where to collect raw customer language (reviews, especially 3-star ones, ad comments, Facebook groups, Reddit, support tickets, sales calls, refund reasons), how to extract tensions with the formula I want, but, because, so our ad should, how to tell data from insight, how to anchor each insight to Drew Eric Whitman's Life-Force 8, how to run Daniel Priestley's 10 beliefs prompt, and how to rank insights into three ad angles. Works from zero, with no brand kit or prior research needed. Use when someone asks why do people buy, what should my ads say, find customer insights, ad angles, customer research, voice of customer, mine my reviews, or wants better Facebook ads, Meta ads or Instagram ads than feature lists.
---

# Facebook Ads: Insight

This skill comes from Gareth Winter's Facebook Ads Live Build. It works on its own: you need no other skill, file or prior conversation.

**What this skill does.** Data tells you what happened. Insight tells you what to say. A useful way to remember the difference: data says a tomato is a fruit; insight says don't put it in a fruit salad. Facebook ads built on real insight stop the scroll because the viewer thinks "that's exactly me". Ads built on features get scrolled past.

## How to run this skill

1. **Get the minimum.** If the user hasn't given them, ask in one short message for: brand name, what they sell, who it's for, the price, and the goal. Nothing else yet.
2. **Use what exists.** If the conversation already contains a brand kit, customer descriptions, reviews or research, read it first and say what you're using. (If you've run the companion skill facebook-ads-brand-kit, paste your brand kit; it helps but isn't required.)
3. **Keep a running document called INSIGHTS** (a file if you can create one, otherwise in the chat). Sections: Raw words, Tensions, Needs, Beliefs, Top three. If a BRAND KIT document exists in the conversation, add the Top three to it as an Insights section.
4. Work through the five steps in order. Explain each framework before using it. Use British spelling.

### Running example used below

Fernhill, a houseplant subscription: each month a plant matched to your light and your schedule, plus a care card. £18 a month. (Illustration only; replace it with the user's brand.)

## Step 1: Gather raw customer words

The goal is the customer's exact language, not your summary of it. Ask the user what they have, then fill gaps from public sources.

### Where to find raw language

| Source | Why it's useful | What to copy |
|---|---|---|
| **Reviews of your product and competitors'** (website, Amazon, Trustpilot, Google, app stores) | Customers explain what they expected and what happened. | Full sentences, especially the "I was worried that..." and "I finally..." lines. |
| **3-star reviews in particular** | 5-star reviews gush and 1-star reviews rant. 3-star reviews are balanced and say what nearly worked and what's missing. | The "but" sentence in each one. |
| **Comments under Facebook and Instagram ads** (yours and competitors', found via facebook.com/ads/library) | Objections, jokes, scepticism and tagged friends, in public. | Objections ("Bet it dies in a week"), questions, the words people use when tagging someone. |
| **Facebook groups** where your customers gather | People talk honestly when no brand is watching. | Questions people ask, the problems they describe, the slang they use. |
| **Reddit** (search "site:reddit.com [problem]" or browse relevant subreddits) | Long, frank posts about what people tried and why it failed. | "I've tried X, Y and Z and nothing works" posts. |
| **Support tickets and DMs** | The problems people have after buying. | Repeated questions and confusions. |
| **Sales calls and enquiries** | What nearly stopped people buying. | Objections, hesitations, comparisons with alternatives. |
| **Refund and cancellation reasons** | Where the promise and the reality didn't match. | The reason, word for word. |
| **Surveys** | Scale, once you know what to ask. | Open-text answers more than scores. |

**Rules for collecting:**
- Copy words exactly, typos included. The odd phrase is often the gold.
- Note the source next to each quote.
- Aim for 30 to 50 raw quotes. Fewer is fine to start, but label the results as hypotheses.
- Never invent quotes. If the user has none, help them collect some before going further, or proceed with clearly labelled assumptions.

### If they have very little: a five-question customer interview

Offer this script for three to five customers (10 minutes each, phone or video). Questions are short, open and non-leading:

1. "What was going on in your life when you started looking for this?"
2. "What did you try before?"
3. "What nearly stopped you buying?"
4. "What happened after you started?"
5. "How would you describe us to a friend?"

Interview tips: ask "tell me more about that" more than any other question, stay quiet after they answer (the second thing they say is often better), and never suggest answers.

## Step 2: Extract the tensions

An insight lives in a tension: something the customer wants, something in the way, and a belief that explains why. Read through the raw words and look for:
- **Contradictions:** "I love plants but I always kill them."
- **Repeated frustrations:** the same complaint in different words from different people.
- **Workarounds:** odd things people do to cope ("I set three alarms to water it").
- **Shame or embarrassment:** things people joke about to cover discomfort.
- **"I thought... but actually..."** moments.

Write the five strongest as:

**"I want ___, but ___, because ___. So our ad should ___."**

- **I want:** the desire, in the customer's words.
- **But:** the obstacle.
- **Because:** the belief behind the obstacle. This is the part your ad can change, so it matters most.
- **So our ad should:** what the ad will do about it.

**Example:** "I want my flat to feel alive, but I've killed every plant I've owned, because I think I'm just not a plant person. So our ad should show that plants die from the wrong match, not the wrong person."

Use the customer's exact words in the first three blanks wherever possible.

## Step 3: Tell data from insight

Before going further, test each tension. Most first attempts are data or observations, not insights.

| Type | What it is | Example |
|---|---|---|
| **Data** | A fact or number. Tells you what. | "62% of buyers are 25 to 34." |
| **Observation** | A pattern in behaviour. Tells you what people do. | "People buy plants in spring and stop in autumn." |
| **Insight** | A human truth that explains why, and suggests what to say. | "People don't think they kill plants; they think they're the kind of person who kills plants. Change the identity and they'll try again." |

**Test:** an insight makes someone say "that's so true" and points directly at an ad. If it only makes them say "interesting", it's still data.

### Worked example: Dove Real Beauty Sketches

Dove's *Real Beauty Sketches* (2013, created with Ogilvy Brazil) is a well-known example of moving from data to insight to execution. (Check the figures below against Dove's published research before quoting them.)

- **Data:** Dove's research reported that only a small percentage of women around the world (often cited as about 4%) would describe themselves as beautiful.
- **Insight:** women judge their own appearance far more harshly than other people do. The tension: "I want to feel beautiful, but I don't, because I see myself more critically than anyone else does."
- **Human need:** social approval (see Step 4).
- **Execution:** a forensic sketch artist, who never sees the women, draws each one twice: once from her own description, once from a stranger's. The stranger's sketch is consistently kinder and more accurate.
- **How it could work on Facebook today:** open on the two sketches side by side with the line "Same woman. Two descriptions." Cut a 15-second captioned version for Reels. Or run a carousel that reveals one sketch per card, ending on the side-by-side.

Note: an ad like this talks about how people see themselves in general. It does not tell the viewer something about their own appearance, which matters under Meta's ad policies.

## Step 4: Anchor each insight to a human need

Drew Eric Whitman, in *Cashvertising*, argues that people are driven by eight biological wants, which he calls the **Life-Force 8**. Ads that connect to one of these are more powerful than ads that only appeal to learned preferences.

### The Life-Force 8 (Whitman)

1. Survival, enjoyment of life, life extension
2. Enjoyment of food and drink
3. Freedom from fear, pain and danger
4. Sexual companionship
5. Comfortable living conditions
6. To be superior, winning, keeping up with the Joneses
7. Care and protection of loved ones
8. Social approval

### The nine learned wants (Whitman)

These are real but weaker on their own:

1. To be informed
2. Curiosity
3. Cleanliness of body and surroundings
4. Efficiency
5. Convenience
6. Dependability and quality
7. Expression of beauty and style
8. Economy and profit
9. Bargains

**How to use them:** for each of your top tensions, name the one Life-Force 8 need it connects to most strongly. If it only connects to a learned want, pair it with a Life-Force 8 need. "Convenience" alone is weak; "convenience so you can look after your family" (care of loved ones) is stronger.

**Example:** Fernhill's tension "I'm not a plant person" connects to comfortable living conditions (a home that feels good) and social approval (friends noticing). Learned wants: convenience and expression of beauty and style.

**An insight is a human need plus the tension in the way.**

## Step 5: The 10 beliefs (Daniel Priestley)

Daniel Priestley, author of *Oversubscribed* and *Key Person of Influence*, suggests a simple prompt to find what your marketing must achieve:

**"What are the 10 beliefs someone would have to hold in order to enthusiastically buy from [brand]?"**

**How to run it:**
1. List ten beliefs. Mix beliefs about the problem, the solution, the brand, the price and the customer themselves.
2. Mark each one: does the customer already hold this (yes, partly, no)?
3. Every "no" or "partly" is a job for an ad. Write a Facebook headline (under 8 words) that installs it.

**Example (Fernhill):**

| Belief | Held? | Headline that installs it |
|---|---|---|
| Plants die from the wrong match, not the wrong owner. | No | "It wasn't you. It was the plant." |
| A plant can be matched to my light. | No | "Your window decides. We listen." |
| £18 a month is fair for a plant that survives. | Partly | "Cheaper than replacing dead ones." |
| I'm the kind of person who can keep plants. | No | "For people who 'can't keep anything alive'." |

### Map the buying tension

Alongside the beliefs, capture four lines:
- **Current reality:** where they are now.
- **Desired reality:** where they want to be.
- **Obstacles:** what's in the way.
- **Tried before:** what they've already tried that didn't work.

Every "tried before" is a ready-made hook: "Tried the watering app? Here's why it didn't work."

## Step 6: Rank and pick three

Score each insight 1 to 5 on three questions:

1. **Is it true?** Supported by real customer words, not just a hunch.
2. **Is it surprising?** Would the customer feel seen, not just informed?
3. **Is it ownable?** Could only this brand say it credibly?

Add the scores. Keep the top three. For each, write one ad angle in a sentence.

**Guardrails:**
- Never invent statistics, quotes or research.
- If the user has little or no real customer data, label every insight "hypothesis to test", and recommend testing the top three as separate ad angles before treating any as fact.
- Don't build insights around the viewer's personal attributes (health, finances, appearance and so on) in a way that would lead to ads that say "you have this problem". Meta's policies reject that. Frame insights about the situation, not the person.

## Deliverable

```
INSIGHTS: [Brand name]
Data quality: [Real customer data / Partly real / Hypotheses only]

RAW WORDS (best 10)
- "[quote]" (source)
- ...

TENSIONS
1. I want ___, but ___, because ___. So our ad should ___.
2. ...
(5 total)

DATA vs INSIGHT CHECK
[One line per tension: insight / still data, and why]

NEEDS (Life-Force 8 + learned wants)
1. [Tension] : [LF8 need] + [learned want]
...

10 BELIEFS
| Belief | Held? | Headline (under 8 words) |
...

BUYING TENSION
Current reality: ...
Desired reality: ...
Obstacles: ...
Tried before: ...

TOP THREE INSIGHTS (ranked: true / surprising / ownable)
1. [Insight] | Score [x/15] | Angle: [one sentence]
2. ...
3. ...

NEXT STEP
Test these three as separate ad angles.
```

Close by saying: "These three insights are your ad angles. Paste them into any chat where you're writing ads. If you want help turning them into ads and a test plan, the optional companion skill is facebook-ads-static."
