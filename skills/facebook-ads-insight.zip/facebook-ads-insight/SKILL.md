---
name: facebook-ads-insight
description: Turns customer data into human insights for Facebook ads, using the "I want, but, because" formula, the Life-Force 8 needs and the 10 beliefs prompt, with Facebook comments and the Meta Ad Library as sources. Use when someone has a brand kit and wants insights, angles or "why people buy" before writing Facebook ads.
---

# Facebook Ads: Insight

Part 2 of 4 in Gareth Winter's Facebook Ads Live Build. "Data says the tomato is a fruit. Insight says don't put it in a fruit salad." (Gareth Winter). Data tells you what happened; insight tells you what to say.

Read MY BRAND KIT first if it exists in the conversation or files. Add everything you produce to its Insights section.

## Step 1: Gather raw words

Ask for whatever the user has: reviews (the 3-star ones are the most honest), comments and DMs, support tickets, sales-call objections, refund reasons, survey answers. If they have little data, point them to free Facebook sources:
- Comments under their own and competitors' Facebook ads: objections, jokes and exact phrasing, in public.
- Facebook groups where their customers talk when no brand is watching.
- The Meta Ad Library: which competitor ads have run for months.
Offer a 5-question customer interview (under 15 words per question, open, non-leading), including "What nearly stopped you buying?", "What did you try before?" and "How would you describe us to a friend?"

## Step 2: Find the tensions

From the raw words, find the 5 recurring tensions. Write each as:
**"I want ___, but ___, because ___. So our ad should ___."**
Use the customer's exact words where possible. The "because" is the belief you can play with.

## Step 3: Anchor to a human need

Map the top insights to Drew Eric Whitman's Life-Force 8 (Cashvertising): survival and long life; food and drink; freedom from fear, pain and danger; sexual companionship; comfortable living; being superior or winning; care and protection of loved ones; social approval. Learned wants (information, curiosity, cleanliness, efficiency, convenience, quality, beauty and style, economy, bargains) are weaker alone, so pair one with an LF8 need. An insight is a human need plus the tension in the way.

Worked example (Dove Real Beauty Sketches): data, few women describe themselves as beautiful; insight, women judge themselves more harshly than others do (social approval); execution, a sketch artist draws each woman from her own description and from a stranger's. On Facebook: open on both sketches side by side, cut to 15 seconds with captions, or reveal one sketch per carousel card.

## Step 4: The 10 beliefs (after Daniel Priestley)

Ask: "What are the 10 beliefs someone would have to have in order to enthusiastically buy from [brand]?" Mark which the customer already holds. Every belief they don't hold yet becomes a Facebook headline (under 8 words) that installs it. Also map the buying tension: current reality, desired reality, obstacles, what they tried that didn't work. Every "tried before" is a ready-made hook.

## Step 5: Pick three

Rank on: is it true, is it surprising, could only this brand say it? Keep the top 3 in MY BRAND KIT. Then say: "Next: the facebook-ads-static skill."

## Guardrail

Never invent statistics or quotes. If the user has no data, label insights as hypotheses to test, not facts.
