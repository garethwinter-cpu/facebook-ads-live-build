---
name: facebook-ads-brand-kit
description: Builds a brand kit before you write any Facebook ad: purpose, values, position, audience, tone of voice, visual identity, proof and offer, kept in one running MY BRAND KIT document. Use when someone says "start my brand kit", "build my brand", "define my positioning" or is about to write Facebook ads with no brand foundations.
---

# Facebook Ads: Brand Kit

Part 1 of 4 in Gareth Winter's Facebook Ads Live Build. No brand, no ads: every Facebook ad is your brand under pressure, and the brand kit is what makes AI copy sound like you instead of everyone else in the feed.

## How to run it

1. **Set up.** Ask for four things if you don't have them: brand name, what they sell, who it's for, price. Then create a running document called **MY BRAND KIT** (a file if you can create files, otherwise keep it in the chat) with sections: Purpose, Values, Position, Audience, Tone of voice, Visual identity, Proof, Offer, Insights, Angles, Winning ad. After each step, update it and show only the section that changed.
2. **Work through the eight questions in order**, one question at a time. Interview, don't lecture. Be blunt when an answer is vague or could belong to any brand.
3. Use British spelling. No jargon the user didn't use first.

## The eight questions

**1. Purpose (why you exist).** Ask: Why did you really start this? What changes in the world because you exist? What would customers lose if you vanished tomorrow? What makes you angry about your industry? Then write 3 purpose statements under 15 words. Ban "empower", "transform" and "journey". Recommend one.

**2. Values (what you'd pay to protect).** For each value the user offers, test: Have you ever lost money or a customer to protect it? Would a competitor say exactly the same? Can a customer see it in what you do? Keep what passes; rewrite the rest as "We [do X] even when [it costs Y]".

**3. Position (the space only you own).** Fill in three versions of: "For [who] who [struggle], [brand] is the [category] that [benefit], unlike [the alternative], because [proof]." Run the steal test (could a competitor put their logo on it?) and the enemy test (what does it stand against?). Pick one.

**4. Market sophistication (Eugene Schwartz).** Ask the user to pull 5 competitor ads from the Meta Ad Library (facebook.com/ads/library) and note how long each has run. Diagnose the stage: 1 first claim, 2 bigger claim, 3 new mechanism, 4 better mechanism, 5 identity. Long-running ads are usually the profitable ones; say what they share. Recommend leading with a claim, a mechanism or an identity.

**5. Audience (one person, described like a friend).** Name, age, a normal Tuesday, what they've tried, the exact words they use to complain. Check Pain, Urgent, Pay: do they hurt, need it now, and can they pay? Flag the weakest.

**6. Tone of voice (four dials, after Nielsen Norman Group).** Score 1 to 5: funny to serious, casual to formal, irreverent to respectful, enthusiastic to matter-of-fact. Write "We are X, never Y" for three traits. Rewrite one line from their website in that voice.

**7. Visual identity.** Propose 2 main colours and 1 accent (hex), a headline and body font from Google Fonts, a photo style in one sentence, and 3 things the visuals must never do. These feed every AI image prompt later.

**8. Proof and offer.** Sort their proof strongest to weakest and name the proof the customer would most want but is missing. Score the offer on Alex Hormozi's value equation (dream outcome, likelihood of success, time delay, effort). Give 3 ways to add value without cutting price and one honest reason to act now. Never invent proof, numbers or reviews.

## Finish with two lines

- **Transformation statement:** "From [how they feel now] to [how they want to feel]", in words a customer would say out loud. Give 3 options.
- **Social pitch (after Daniel Priestley):** Name, Same (the category anyone instantly understands), Fame (your proof), Pain, Aim (what you're focused on now), Game (your bigger why). Under 40 seconds spoken.

Then tell the user: "Your brand kit is ready. Next: the facebook-ads-insight skill."
