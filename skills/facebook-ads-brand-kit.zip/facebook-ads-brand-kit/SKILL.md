---
name: facebook-ads-brand-kit
description: Builds a complete brand kit for Facebook and Instagram advertising from scratch, by interview, for anyone starting with no brand documents. Covers purpose, values, positioning, market sophistication (diagnosed with the Meta Ad Library), audience, tone of voice, visual identity, proof and offer, then a transformation statement and a Daniel Priestley social pitch. Produces one paste-ready BRAND KIT document that makes AI-written ads sound like your brand instead of everyone else in the feed. Use when someone says build my brand kit, define my brand, help with positioning, who is my customer, what is my tone of voice, improve my offer, or wants to write Facebook ads, Meta ads or Instagram ads but has no brand foundations yet. Works for a new business, a side project or an established brand that has never written these things down.
---

# Facebook Ads: Brand Kit

This skill comes from Gareth Winter's Facebook Ads Live Build. It works on its own: you need no other skill, file or prior conversation.

**Why this comes first.** Every Facebook ad is your brand under pressure: one second, one image, one line, competing with friends' photos and every other advertiser. If the brand is vague, the AI fills the gaps with generic copy that sounds like everyone else. A brand kit is the short set of decisions that stops that.

## How to run this skill

1. **Get the minimum.** If the user hasn't already given them, ask in one short message for: brand name, what they sell, who it's for, the price, and the goal (for example, more sales, more leads, a launch). Don't ask anything else yet. If they only have a vague idea, accept rough answers and move on.
2. **Check for existing material.** If the conversation already contains a brand kit, website copy, a pitch deck or customer reviews, read them and pre-fill answers. Say what you pre-filled so the user can correct it.
3. **Start a running document called BRAND KIT.** If you can create files, create one; otherwise keep it in the chat. Sections: Basics, Purpose, Values, Position, Market sophistication, Audience, Tone of voice, Visual identity, Proof, Offer, Transformation statement, Social pitch. After each step, update it and show only the section that changed.
4. **Interview, don't lecture.** One question at a time (or one small group of related questions). Give your draft answer only after hearing theirs. Be direct when an answer is vague or could belong to any brand: say so, explain why, and offer a sharper version.
5. Use British spelling. Don't use jargon the user hasn't used first, and explain any framework you name.

### Interview technique (use throughout)

- **Ask for stories, not adjectives.** "Tell me about the last customer who loved you" gets better material than "describe your brand".
- **Ask "why" up to three times.** The first answer is usually the polite one. The third is usually the true one.
- **Ask for specifics.** Numbers, names, places, moments. "Busy mums" becomes "a mum of two in Leeds who answers work emails at 6am".
- **Play it back.** Summarise what you heard in one line and ask "Is that right, or is it more like...?"
- **Apply the swap test.** If you could swap the brand name for a competitor's and the sentence still works, it isn't finished.
- **Never invent.** If the user doesn't know something, mark it "To find out" in the BRAND KIT. Don't make up facts, numbers, reviews or history.

### Running example used below

Fernhill, a houseplant subscription: each month a plant matched to your light and your schedule, plus a one-page care card. £18 a month. Goal: subscriptions from Facebook and Instagram ads. (This is an illustration only; replace it with the user's brand.)

## The eight answers

### 1. Purpose: why you exist

**Ask:** Why did you really start this? What changes because you exist? What would customers lose if you vanished tomorrow? What annoys you about your industry?

**Then:** Write three purpose statements, each under 15 words, and recommend one.

**Quality bar:**
- Concrete enough to picture. Ban "empower", "transform", "journey", "elevate" and "unlock".
- Says what changes for the customer, not what the company does.
- Passes the swap test.

**Example.** Weak: "We empower people to bring nature into their homes." Strong: "Nobody should feel like a plant murderer. We make keeping plants alive easy."

### 2. Values: what you'd pay to protect

**Ask:** List three to five values. For each one, test it:
- Have you ever lost money or a customer to protect it?
- Would a competitor say exactly the same?
- Could a customer see it in what you actually do?

**Then:** Keep the values that pass. Rewrite each as "We [do X] even when [it costs Y]."

**Quality bar:** A value is only real if it costs something. "Quality" and "integrity" fail unless there's a cost attached.

**Example.** Weak: "Sustainability." Strong: "We ship in compostable packaging even though it costs us 40p more per box." (Use the user's real figure, or leave it out.)

### 3. Position: the space only you own

**Ask:** Who else could the customer buy from instead, including "do nothing" or "do it myself"? What do you do that they don't?

**Then:** Write three versions of this positioning sentence and pick one:

"For [who] who [struggle], [brand] is the [category] that [benefit], unlike [the alternative], because [proof]."

Run two tests on each:
- **Steal test:** could a competitor put their logo on it? If yes, sharpen the struggle or the proof.
- **Enemy test:** what does it stand against? A position with no enemy (a bad habit, an old way, a frustration) is usually too soft to advertise.

**Example.** "For busy people who've killed every plant they've owned, Fernhill is the plant subscription that matches each plant to your light and schedule, unlike garden centres that sell you whatever looks nice, because every plant arrives with a care card written for your home."

### 4. Market sophistication: how jaded is your market?

This comes from Eugene Schwartz, *Breakthrough Advertising* (1966). It tells you what kind of message will still work, given how many similar promises your customer has already heard.

**The five stages of market sophistication:**

| Stage | What the market has seen | What works | Example line |
|---|---|---|---|
| 1 | Nothing like you. You're first. | State the claim simply. | "Houseplants, delivered monthly." |
| 2 | Others make the same claim. | Make the claim bigger or more specific. | "The plant subscription with a 30-day thrive guarantee." |
| 3 | Claims have been exaggerated to death. | Introduce a new mechanism: how it works. | "We match every plant to your window's light." |
| 4 | Competitors copied your mechanism. | A better, faster or easier mechanism. | "Snap your window, get a plant matched in 10 seconds." |
| 5 | The market is exhausted and sceptical of all claims. | Identity and belonging: who the customer becomes. | "For people who swore they'd never keep anything alive." |

**How to diagnose it with the Meta Ad Library (free, no account needed):**

1. Go to facebook.com/ads/library. Choose the country, set ad category to "All ads" and search for three to five competitor brand names, plus a keyword for the category (for example "plant subscription").
2. Open five to ten active ads. For each, note: the main claim, any mechanism (the "how"), any identity language, and the start date ("Started running on...").
3. **Ads that have run for months are usually the profitable ones**, because advertisers switch off losers. Treat long-running ads as the market's proven messages.
4. List what the long-runners have in common. If they all shout the same claim, the market is at stage 2 or 3. If they all explain a mechanism, it's stage 3 or 4. If they talk about identity and community, it's stage 5.
5. Recommend whether the user should lead with a claim, a mechanism or an identity, and why.

**Also capture the level of awareness** (also Schwartz). It decides how your ad should open:

| Level | The customer... | So the ad opens with... |
|---|---|---|
| Unaware | doesn't know they have the problem | a story, a surprising fact or a relatable moment |
| Problem aware | feels the problem, doesn't know solutions exist | the problem, in their words |
| Solution aware | knows solutions exist, not yours | why your way is different |
| Product aware | knows you, isn't convinced | proof, objections answered, a reason to act |
| Most aware | wants it, needs a nudge | the offer, plainly |

Most cold Facebook audiences are problem aware or solution aware. Note which level the user's main audience sits at.

### 5. Audience: one person, described like a friend

**Ask:** Describe one real customer. Name (invented is fine), age range, what a normal Tuesday looks like, what they've already tried, and the exact words they use to complain.

**Quality bar:**
- Specific enough that two people would picture the same person.
- Includes at least one direct quote in the customer's own words (from a review, comment, DM or conversation). If none exist, mark "To find out".
- Lists what they've tried before. Every failed attempt is a future hook.

**Then check Pain, Urgent, Pay.** A market is worth advertising to when all three are true:
- **Pain:** does it genuinely hurt, or is it a mild preference?
- **Urgent:** do they need it solved now, or "someday"?
- **Pay:** can they afford it, and do they already spend money on the problem?

Score each 1 to 5 and flag the weakest. A weak "Urgent" means the ads need a reason to act now. A weak "Pay" means the offer or the audience needs rethinking.

**Example.** "Priya, 31, works hybrid in Manchester. Bought a fiddle-leaf fig, watched it drop every leaf in six weeks. Says: 'I literally can't keep anything alive.' Tried: garden centre plants, a watering app she forgot to open. Pain 3, Urgent 2, Pay 4." Weakest: Urgent, so the ads will need a seasonal or emotional trigger.

### 6. Tone of voice: four dials

Nielsen Norman Group's tone of voice research describes tone along four dimensions. Score the brand 1 to 5 on each:

1. **Funny to serious**
2. **Casual to formal**
3. **Irreverent to respectful**
4. **Enthusiastic to matter-of-fact**

**Then:**
- Write three "We are X, never Y" rules. Example: "We are warm, never twee. We are plain-spoken, never blunt. We are playful, never silly."
- Write a short list of words the brand uses and words it never uses.
- Take one real line from the user's website or social posts and rewrite it in this voice, so they can hear the difference.

**Quality bar:** two different writers given these rules would produce copy that sounds like the same brand.

### 7. Visual identity

Every AI image prompt later will be built from this section, so make it precise.

**Propose:**
- Two main colours and one accent, as hex codes.
- A headline font and a body font (Google Fonts, so anyone can use them).
- Photo style in one sentence (lighting, setting, people or no people, polished or phone-shot).
- Three things the visuals must never do.

**Quality bar:** someone who has never seen the brand could brief a designer or an AI image tool from this section alone.

**Example.** Colours: deep fern #2F5D50, warm linen #F3EDE2, accent terracotta #C8664A. Fonts: Fraunces (headlines), Inter (body). Photo style: real flats in soft daylight, plants on cluttered windowsills, phone-shot not studio. Never: stock-photo jungles, perfect white studios, plants that look plastic.

### 8. Proof and offer

**Proof.** List every piece of proof the user has: reviews, star ratings, customer numbers, press, awards, guarantees, founder credentials, before-and-after results, demonstrations. Sort strongest to weakest. Strongest proof is specific, verifiable and from someone other than the brand.

Then name the proof the customer would most want but is missing, and suggest one way to get it (for example, ask the last 20 customers for a one-line review).

**Never invent proof, numbers, reviews or testimonials.** Mark gaps as gaps.

**Offer.** Score the offer on Alex Hormozi's value equation (from *$100M Offers*):

**Value = (Dream outcome x Perceived likelihood of achievement) / (Time delay x Effort and sacrifice)**

- **Dream outcome:** how big and desirable is the result? Push up.
- **Perceived likelihood:** how sure is the customer it will work for them? Push up with proof and guarantees.
- **Time delay:** how long until they see results? Push down.
- **Effort and sacrifice:** how much do they have to do or give up? Push down.

Score each 1 to 5. Then give three ways to add value **without cutting the price** (for example, a guarantee, a faster first result, a bonus that removes effort), and one honest reason to act now. A real reason is a real deadline, real limited stock, a seasonal moment or a genuine price change. Never suggest fake scarcity or fake countdowns.

**Example.** Fernhill: dream outcome 3, likelihood 2, time delay 4 (first plant in 3 days), effort 4. Weakest is likelihood. Fixes: a "thrive or we replace it" guarantee, a care card written for their light, a 2-minute care video per plant.

## Finish with two lines

### Transformation statement

"From [how they feel now] to [how they want to feel]," in words a customer would actually say out loud. Write three options and recommend one.

Example: "From 'I kill every plant' to 'my flat finally feels alive'."

Quality bar: both halves are feelings or identities, not product features, and both sound like speech.

### Social pitch (Daniel Priestley)

Daniel Priestley, author of *Key Person of Influence*, uses a six-part pitch you can say in under 40 seconds. Each part is one or two sentences:

1. **Name:** who you are and the brand.
2. **Same:** the category anyone instantly understands ("It's a plant subscription").
3. **Fame:** the proof that makes you credible (only real proof).
4. **Pain:** the problem your customer has, in their words.
5. **Aim:** what you're focused on right now.
6. **Game:** your bigger reason for doing it.

Example: "I'm Sam, I run Fernhill. It's a houseplant subscription. [Fame: use the real figure, e.g. number of plants shipped, or leave out.] Most people tell us they kill every plant they buy. Right now we're focused on matching plants to the light in people's actual flats. We think everyone deserves a home that feels alive, even if they've never kept anything green."

Read it aloud. If it takes longer than 40 seconds or sounds like a brochure, cut it.

## Deliverable

When all sections are done, present the final BRAND KIT in this format, under 600 words, so the user can paste it at the top of any future AI chat:

```
BRAND KIT: [Brand name]
Last updated: [date]

BASICS
Product: [what you sell] | Price: [price] | Goal: [goal]

PURPOSE
[One sentence]

VALUES
- We [do X] even when [it costs Y]
- ...

POSITION
For [who] who [struggle], [brand] is the [category] that [benefit], unlike [alternative], because [proof].

MARKET
Sophistication stage: [1 to 5], so lead with [claim / mechanism / identity]
Awareness level of main audience: [level], so open with [what]
Proven competitor messages (Ad Library): [2 to 3 bullets]

AUDIENCE
[Name, age, Tuesday, tried before]
In their words: "[quote]"
Pain [x/5] | Urgent [x/5] | Pay [x/5]. Weakest: [which]

TONE OF VOICE
Funny-serious [x] | Casual-formal [x] | Irreverent-respectful [x] | Enthusiastic-matter-of-fact [x]
We are [X], never [Y] (x3)
Use: [words] | Never use: [words]

VISUAL IDENTITY
Colours: [hex, hex, accent hex] | Fonts: [headline], [body]
Photo style: [one sentence]
Never: [three things]

PROOF (strongest first)
- ...
Missing proof to get: [what]

OFFER
Value equation: Dream [x] | Likelihood [x] | Time [x] | Effort [x]
Value adds: [three]
Honest reason to act now: [one]

TRANSFORMATION
From "[now]" to "[want]"

SOCIAL PITCH
[Under 40 seconds]

TO FIND OUT
- [gaps marked during the interview]
```

Close by telling the user: "Your brand kit is ready. Paste it at the start of any chat where you're writing ads. If you want to go further, the optional companion skills are facebook-ads-insight (customer insights), facebook-ads-static (static ads and testing) and facebook-ads-video (video ads), but each also works without them."
